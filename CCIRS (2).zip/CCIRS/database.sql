-- ============================================================
-- Crowdsourced Civic Issue Reporting System (CCIRS)
-- Database creation script
-- Note: Flask-SQLAlchemy will auto-create these tables via
-- db.create_all() the first time you run app.py. This script
-- is provided for reference / manual setup if you prefer.
-- ============================================================

CREATE DATABASE IF NOT EXISTS ccirs;
USE ccirs;

-- ----------------------------
-- Users table
-- ----------------------------
CREATE TABLE IF NOT EXISTS user (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    is_admin BOOLEAN NOT NULL DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ----------------------------
-- Issues / Reports table
-- ----------------------------
CREATE TABLE IF NOT EXISTS issue (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    category VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    location VARCHAR(200) NOT NULL,
    image_filename VARCHAR(255),
    status VARCHAR(20) NOT NULL DEFAULT 'Pending',
    user_id INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE
);

-- ----------------------------
-- Seed an admin account
-- Email: admin@ccirs.com  Password: admin123
-- (password_hash below corresponds to "admin123" using
--  Werkzeug's default pbkdf2 hasher — regenerate this via
--  app.py / the seed script instead of relying on this literal
--  hash, since Werkzeug hashes are salted/random per run.)
-- ----------------------------
-- Recommended: create the admin using the `flask create-admin`
-- CLI command included in app.py rather than inserting manually.
