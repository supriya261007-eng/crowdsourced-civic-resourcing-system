from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import (
    StringField,
    PasswordField,
    TextAreaField,
    SelectField,
    SubmitField,
)
from wtforms.validators import DataRequired, Email, Length, EqualTo
from models import Issue


class RegisterForm(FlaskForm):
    name = StringField("Full Name", validators=[DataRequired(), Length(min=2, max=100)])
    email = StringField("Email", validators=[DataRequired(), Email()])
    password = PasswordField("Password", validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField(
        "Confirm Password",
        validators=[DataRequired(), EqualTo("password", message="Passwords must match")],
    )
    submit = SubmitField("Register")


class LoginForm(FlaskForm):
    email = StringField("Email", validators=[DataRequired(), Email()])
    password = PasswordField("Password", validators=[DataRequired()])
    submit = SubmitField("Login")


class IssueForm(FlaskForm):
    title = StringField("Title", validators=[DataRequired(), Length(max=150)])
    category = SelectField(
        "Category", choices=[(c, c) for c in Issue.CATEGORY_CHOICES], validators=[DataRequired()]
    )
    description = TextAreaField("Description", validators=[DataRequired(), Length(max=2000)])
    location = StringField("Location", validators=[DataRequired(), Length(max=200)])
    image = FileField(
        "Photo (optional)",
        validators=[FileAllowed(["jpg", "jpeg", "png", "gif", "webp"], "Images only!")],
    )
    submit = SubmitField("Submit Report")


class StatusUpdateForm(FlaskForm):
    status = SelectField(
        "Status", choices=[(s, s) for s in Issue.STATUS_CHOICES], validators=[DataRequired()]
    )
    submit = SubmitField("Update Status")
