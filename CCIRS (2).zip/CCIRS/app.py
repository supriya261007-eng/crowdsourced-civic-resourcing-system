import os
import uuid
from functools import wraps

from flask import (
    Flask,
    render_template,
    redirect,
    url_for,
    flash,
    request,
    abort,
)
from flask_login import (
    LoginManager,
    login_user,
    logout_user,
    login_required,
    current_user,
)
from werkzeug.utils import secure_filename
from flask_wtf.csrf import CSRFProtect, generate_csrf

from config import Config
from models import db, User, Issue
from forms import RegisterForm, LoginForm, IssueForm, StatusUpdateForm

# ------------------------------------------------------------------
# App factory / setup
# ------------------------------------------------------------------
app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)
csrf = CSRFProtect(app)
app.jinja_env.globals["csrf_token"] = generate_csrf

login_manager = LoginManager()
login_manager.login_view = "login"
login_manager.login_message_category = "warning"
login_manager.init_app(app)

os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            abort(403)
        return view(*args, **kwargs)
    return wrapped


def allowed_file(filename):
    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower() in app.config["ALLOWED_EXTENSIONS"]
    )


def save_image(file_storage):
    """Save an uploaded image with a unique filename, return the filename."""
    filename = secure_filename(file_storage.filename)
    ext = filename.rsplit(".", 1)[1].lower()
    unique_name = f"{uuid.uuid4().hex}.{ext}"
    file_storage.save(os.path.join(app.config["UPLOAD_FOLDER"], unique_name))
    return unique_name


# ------------------------------------------------------------------
# Public pages
# ------------------------------------------------------------------
@app.route("/")
def index():
    total_issues = Issue.query.count()
    resolved_issues = Issue.query.filter_by(status="Resolved").count()
    pending_issues = Issue.query.filter_by(status="Pending").count()
    total_users = User.query.count()
    recent_reports = Issue.query.order_by(Issue.created_at.desc()).limit(6).all()

    return render_template(
        "index.html",
        total_issues=total_issues,
        resolved_issues=resolved_issues,
        pending_issues=pending_issues,
        total_users=total_users,
        recent_reports=recent_reports,
    )


# ------------------------------------------------------------------
# Auth: Register / Login / Logout
# ------------------------------------------------------------------
@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))

    form = RegisterForm()
    if form.validate_on_submit():
        existing = User.query.filter_by(email=form.email.data.lower()).first()
        if existing:
            flash("An account with that email already exists.", "danger")
            return render_template("register.html", form=form)

        user = User(name=form.name.data.strip(), email=form.email.data.lower())
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()

        flash("Account created successfully! Please log in.", "success")
        return redirect(url_for("login"))

    return render_template("register.html", form=form)


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data.lower()).first()
        if user and user.check_password(form.password.data):
            login_user(user)
            flash(f"Welcome back, {user.name}!", "success")
            next_page = request.args.get("next")
            if user.is_admin:
                return redirect(next_page or url_for("admin_dashboard"))
            return redirect(next_page or url_for("dashboard"))
        flash("Invalid email or password.", "danger")

    return render_template("login.html", form=form)


@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You have been logged out.", "info")
    return redirect(url_for("index"))


# ------------------------------------------------------------------
# User dashboard
# ------------------------------------------------------------------
@app.route("/dashboard")
@login_required
def dashboard():
    my_reports_count = Issue.query.filter_by(user_id=current_user.id).count()
    resolved_count = Issue.query.filter_by(
        user_id=current_user.id, status="Resolved"
    ).count()
    pending_count = Issue.query.filter_by(
        user_id=current_user.id, status="Pending"
    ).count()
    recent = (
        Issue.query.filter_by(user_id=current_user.id)
        .order_by(Issue.created_at.desc())
        .limit(5)
        .all()
    )
    return render_template(
        "dashboard.html",
        my_reports_count=my_reports_count,
        resolved_count=resolved_count,
        pending_count=pending_count,
        recent=recent,
    )


# ------------------------------------------------------------------
# Report an issue (create + edit)
# ------------------------------------------------------------------
@app.route("/report", methods=["GET", "POST"])
@app.route("/report/<int:issue_id>", methods=["GET", "POST"])
@login_required
def report(issue_id=None):
    issue = None
    if issue_id:
        issue = Issue.query.get_or_404(issue_id)
        if issue.user_id != current_user.id:
            abort(403)

    form = IssueForm(obj=issue)

    if form.validate_on_submit():
        image_filename = issue.image_filename if issue else None

        if form.image.data and allowed_file(form.image.data.filename):
            image_filename = save_image(form.image.data)

        if issue:
            issue.title = form.title.data.strip()
            issue.category = form.category.data
            issue.description = form.description.data.strip()
            issue.location = form.location.data.strip()
            issue.image_filename = image_filename
            flash("Report updated successfully!", "success")
        else:
            issue = Issue(
                title=form.title.data.strip(),
                category=form.category.data,
                description=form.description.data.strip(),
                location=form.location.data.strip(),
                image_filename=image_filename,
                user_id=current_user.id,
            )
            db.session.add(issue)
            flash("Issue reported successfully! Thank you for helping your community.", "success")

        db.session.commit()
        return redirect(url_for("myreports"))

    return render_template("report.html", form=form, editing=issue is not None)


@app.route("/report/<int:issue_id>/delete", methods=["POST"])
@login_required
def delete_report(issue_id):
    issue = Issue.query.get_or_404(issue_id)
    if issue.user_id != current_user.id and not current_user.is_admin:
        abort(403)

    if issue.image_filename:
        image_path = os.path.join(app.config["UPLOAD_FOLDER"], issue.image_filename)
        if os.path.exists(image_path):
            os.remove(image_path)

    db.session.delete(issue)
    db.session.commit()
    flash("Report deleted.", "info")

    if current_user.is_admin and request.referrer and "admin" in request.referrer:
        return redirect(url_for("admin_dashboard"))
    return redirect(url_for("myreports"))


# ------------------------------------------------------------------
# My reports (with search/filter)
# ------------------------------------------------------------------
@app.route("/myreports")
@login_required
def myreports():
    query = Issue.query.filter_by(user_id=current_user.id)

    status = request.args.get("status", "")
    search = request.args.get("q", "")

    if status:
        query = query.filter_by(status=status)
    if search:
        query = query.filter(Issue.title.ilike(f"%{search}%"))

    reports = query.order_by(Issue.created_at.desc()).all()

    return render_template(
        "myreports.html",
        reports=reports,
        statuses=Issue.STATUS_CHOICES,
        current_status=status,
        search=search,
    )


# ------------------------------------------------------------------
# Admin dashboard
# ------------------------------------------------------------------
@app.route("/admin")
@login_required
@admin_required
def admin_dashboard():
    query = Issue.query

    status = request.args.get("status", "")
    category = request.args.get("category", "")
    search = request.args.get("q", "")

    if status:
        query = query.filter_by(status=status)
    if category:
        query = query.filter_by(category=category)
    if search:
        query = query.filter(
            (Issue.title.ilike(f"%{search}%")) | (Issue.location.ilike(f"%{search}%"))
        )

    reports = query.order_by(Issue.created_at.desc()).all()

    stats = {
        "total": Issue.query.count(),
        "pending": Issue.query.filter_by(status="Pending").count(),
        "in_progress": Issue.query.filter_by(status="In Progress").count(),
        "resolved": Issue.query.filter_by(status="Resolved").count(),
        "users": User.query.count(),
    }

    return render_template(
        "admin_dashboard.html",
        reports=reports,
        stats=stats,
        statuses=Issue.STATUS_CHOICES,
        categories=Issue.CATEGORY_CHOICES,
        current_status=status,
        current_category=category,
        search=search,
    )


@app.route("/admin/issue/<int:issue_id>/status", methods=["POST"])
@login_required
@admin_required
def update_status(issue_id):
    issue = Issue.query.get_or_404(issue_id)
    form = StatusUpdateForm()
    if form.validate_on_submit():
        issue.status = form.status.data
        db.session.commit()
        flash(f"Status for '{issue.title}' updated to {issue.status}.", "success")
    return redirect(url_for("admin_dashboard"))


# ------------------------------------------------------------------
# Error handlers
# ------------------------------------------------------------------
@app.errorhandler(403)
def forbidden(e):
    return render_template("errors.html", code=403, message="Access forbidden."), 403


@app.errorhandler(404)
def not_found(e):
    return render_template("errors.html", code=404, message="Page not found."), 404


# ------------------------------------------------------------------
# CLI helper: create an admin user
#   Usage: flask --app app.py create-admin
# ------------------------------------------------------------------
@app.cli.command("create-admin")
def create_admin():
    import getpass

    name = input("Admin name: ").strip()
    email = input("Admin email: ").strip().lower()
    password = getpass.getpass("Admin password: ")

    if User.query.filter_by(email=email).first():
        print("A user with that email already exists.")
        return

    admin = User(name=name, email=email, is_admin=True)
    admin.set_password(password)
    db.session.add(admin)
    db.session.commit()
    print(f"Admin account created for {email}")


with app.app_context():
    db.create_all()


if __name__ == "__main__":
    app.run(debug=True)
