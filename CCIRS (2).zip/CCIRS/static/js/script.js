// Auto-dismiss flash messages after 4 seconds
document.addEventListener("DOMContentLoaded", function () {
  const alerts = document.querySelectorAll(".alert");
  alerts.forEach(function (alert) {
    setTimeout(function () {
      const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
      if (bsAlert) bsAlert.close();
    }, 4000);
  });

  // Image preview before upload (report form)
  const imageInput = document.querySelector('input[type="file"][name="image"]');
  if (imageInput) {
    imageInput.addEventListener("change", function (e) {
      const file = e.target.files[0];
      let preview = document.getElementById("image-preview");
      if (!preview) {
        preview = document.createElement("img");
        preview.id = "image-preview";
        preview.style.maxWidth = "200px";
        preview.style.borderRadius = "10px";
        preview.style.marginTop = "10px";
        imageInput.insertAdjacentElement("afterend", preview);
      }
      if (file) {
        preview.src = URL.createObjectURL(file);
      }
    });
  }
});
