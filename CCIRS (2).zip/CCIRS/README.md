# CCIRS — Crowdsourced Civic Issue Reporting System

A full-stack web app where citizens can report civic issues (potholes, broken
streetlights, garbage, water leaks, etc.) with a photo and location, track
their status, and admins can review, filter, and update report status.

## Tech Stack
- **Backend:** Python 3.13, Flask
- **ORM:** Flask-SQLAlchemy
- **Auth:** Flask-Login, Flask-WTF (CSRF-protected forms)
- **Database:** MySQL (via PyMySQL driver)
- **Frontend:** HTML, CSS, JavaScript, Bootstrap 5

## Project Structure
```
CCIRS/
├── app.py                 # Main Flask app + routes
├── config.py               # App configuration (DB URI, upload settings)
├── models.py                # SQLAlchemy models: User, Issue
├── forms.py                  # Flask-WTF forms
├── database.sql               # Reference SQL schema (optional, auto-created by SQLAlchemy)
├── requirements.txt
├── static/
│   ├── css/style.css
│   ├── js/script.js
│   └── uploads/             # Uploaded issue photos
└── templates/
    ├── layout.html
    ├── index.html
    ├── login.html
    ├── register.html
    ├── dashboard.html
    ├── report.html
    ├── myreports.html
    ├── admin_dashboard.html
    └── errors.html
```

## Setup Instructions

### 1. Install prerequisites
- Python 3.10+ 
- MySQL Server (running locally or remotely)

### 2. Create a virtual environment
```bash
cd CCIRS
python -m venv venv

# Windows
venv\Scripts\activate

# macOS/Linux
source venv/bin/activate
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Create the MySQL database
```sql
CREATE DATABASE ccirs;
```
(You don't need to run `database.sql` manually — the tables are created
automatically the first time you run the app. It's included for reference.)

### 5. Configure your database credentials
Open `config.py` and either edit the defaults directly, or set environment
variables before running:
```bash
# macOS/Linux
export MYSQL_USER=root
export MYSQL_PASSWORD=your_password
export MYSQL_DB=ccirs
export SECRET_KEY=some-random-string

# Windows (PowerShell)
$env:MYSQL_USER="root"
$env:MYSQL_PASSWORD="your_password"
$env:MYSQL_DB="ccirs"
$env:SECRET_KEY="some-random-string"
```

### 6. Run the app
```bash
python app.py
```
Visit **http://127.0.0.1:5000**

Tables are created automatically on first run.

### 7. Create an admin account
Regular registration (`/register`) always creates a normal citizen account.
To create an admin, run this CLI command (after activating your venv):
```bash
flask --app app.py create-admin
```
Follow the prompts for name, email, and password. Log in at `/login` with
those credentials — admins are automatically redirected to `/admin`.

## Features
- ✔ User registration & login (hashed passwords via Werkzeug)
- ✔ Session management with Flask-Login
- ✔ Report an issue: title, category, description, location, photo upload
- ✔ Edit / delete your own reports
- ✔ "My Reports" page with search & status filter
- ✔ Admin dashboard: view all reports, filter by status/category, search
- ✔ Admin can update status (Pending → Accepted → In Progress → Resolved)
- ✔ Admin can delete any report
- ✔ Home page with live stats (total, resolved, pending, users) and recent reports
- ✔ Flash messages for all key actions
- ✔ CSRF protection on all forms
- ✔ Responsive Bootstrap 5 UI

## Notes
- Uploaded images are stored in `static/uploads/` with randomized filenames
  to avoid collisions and are capped at 5 MB.
- `db.create_all()` is called automatically at startup — it only creates
  tables that don't already exist, so it's safe to leave in for development.
  For production, consider using Flask-Migrate instead.
- Change `SECRET_KEY` before deploying anywhere public.
